# -*- coding: utf-8 -*-
import scrapy
from ..items import Myproject1Item

class SpiderSpider(scrapy.Spider):
    name = 'spider'
    allowed_domains = ['ardb.cbcb.umd.edu']
    start_urls = ['http://ardb.cbcb.umd.edu/browsespecies.shtml']

    def parse(self, response):
        item = Myproject1Item()
        outfile = open('the_out.csv', 'w')
        for iteml in response.css('body > table:nth-child(5) > tbody > tr > td > ul > ul:nth-child(2) > ul > ul:nth-child(2) > ul:nth-child(2) > li:nth-child(1) > a'):
           item['information'] = iteml.css('::text').extract()
           out = item['information']
           outfile.write(out)
        outfile.close()
        yield item
        
