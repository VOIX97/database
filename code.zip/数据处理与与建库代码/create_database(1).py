# -*- coding: utf-8 -*-
from os import system,listdir,environ
import argparse,re

def readfile(fileA):
    filename=str(fileA)
    from_file=open(filename,"r")
    lines=from_file.readlines()
    from_file.close()
    return lines
def write_file(list,name):
    w=open(str(name),'w')
    for i in list:
        w.write(str(i)+'\n')
    w.close()


def query_key_information(filename,content,keyword_list,Strain_Name,rank_num):
    keyword_value=[str(rank_num)]
    if keyword_list[1]=='Accession':
        locus = re.compile('LOCUS       (.*?) ')
        LOCUS = re.findall(locus,content)
        if LOCUS != []:
            keyword_value.append(LOCUS[0])
    if keyword_list[2]=='Protein_ID':
        P_ID = filename.split("_")[1].split('.')[0]
        keyword_value.append(str(P_ID))
    if keyword_list[3]=='Protein_Name':
        Pn = re.compile('DEFINITION  (.*?)\[')
        PN = re.findall(Pn,content)
        if PN != []:
            keyword_value.append(PN[0])
    if keyword_list[4]=='Strains':
        keyword_value.append(Strain_Name)
    if keyword_list[5]=='Organism':
        sc = re.compile('ORGANISM  (.*?)\n')
        St = re.findall(sc,content)
        if St != []:
            keyword_value.append(St[0])
    if keyword_list[6]=='Description':
        desc='data/'+filename
        keyword_value.append(str(desc))
    if len(keyword_value)==7:
        return keyword_value
    else:
        return []

def create_sql_script(filelist,key_information_list):
    outfile=["INSERT INTO final_table1(Rank,Accession,Protein_ID,Protein_Name,Strains,Organism,Description) VALUES"]
    file_num=len(filelist)
    rank_num=0
    Strain_Names=readfile('Strains_Data.csv')
    for index in range(file_num):
        filename=filelist[index]
        f = open('out/'+filename,'r')
        content=f.read()
        rank_num+=1
        Strain_Num=int(filename.split('_')[0])-1
        Strain_Name=Strain_Names[Strain_Num].strip()
        key_information = query_key_information(filename,content,key_information_list,Strain_Name,rank_num)
        if key_information==[]:
            #print("continue")
            continue
        tmp_out='\t('
        first=0
        for info in key_information:
            if first!=0:
                tmp_out+=','
            else:
                first+=1
            tmp_out+='"'+str(info)+'"'
        tmp_out+=')'
        if index==file_num-1:
            tmp_out+=';'
        else:
            tmp_out+=','
        outfile.append(tmp_out)
    print(outfile[0],outfile[-1])
    scriptname="protein_database_test1.sql"#undefined
    return_info=write_file(outfile,scriptname)
    print(return_info)
    return scriptname
#'Rank','Accession','Protein_ID','Protein_Name','Strains','Organism'
def create_sql_table(tablename='final_table1'):
    outfile=["CREATE TABLE IF NOT EXISTS "+tablename+"(",
        "Rank VARCHAR(32) NOT NULL,",
	    "Accession VARCHAR(32) NOT NULL,",
	    "Protein_ID varchar(32) NOT NULL,",
	    "Protein_Name char(255) NOT NULL,",
	    "Strains char(255) NOT NULL,",
        "Organism char(255) NOT NULL,",
        "Description char(255) NOT NULL,",
	    "PRIMARY KEY(Rank)",
        ")ENGINE=InnoDB DEFAULT CHARSET=utf8;",
        "set global max_allowed_packet=1024*1024*1600;"]
    write_file(outfile,'create_table.sql')
    system("mysql --host=127.0.0.1 --port=3306 --user=root --password=8204659 --default-character-set=utf8 test<create_table.sql")

def change_environ():
    system("set MySQL_HOME="+mysql_path)
    system("set PATH=%MySQL_HOME%/bin;%PATH%")
    environ['PATH'] = 'D:\\xampp\\mysql\\;' + environ['PATH']

def file_filter(filelist):
    returnlist=[]
    for filename in filelist:
        try:
            id = filename.split('_')[1]
            if id not in returnlist:
                returnlist.append(filename)
        except:
            continue
    return returnlist


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='Manual to this script, you are supposed to run this script in the superior folder of outfiles.')
    parser.add_argument('-p', type=str, default='D:/xampp/mysql', help='The path of your mysql root folder.')
    parser.add_argument('-sql', nargs='*', default=['Rank','Accession','Protein_ID','Protein_Name','Strains','Organism','Description'],help='the elements of database.')
    args = parser.parse_args()
    #filename = args.i
    key_information_names = args.sql
    mysql_path=args.p
    change_environ()
    all_filelist=listdir('out')
    input_filelist=file_filter(all_filelist)
    scriptname=create_sql_script(filelist=input_filelist,key_information_list=key_information_names)
    create_sql_table()
    system("mysql --host=127.0.0.1 --port=3306 --user=root --password=8204659 --default-character-set=utf8 test<"+scriptname)

